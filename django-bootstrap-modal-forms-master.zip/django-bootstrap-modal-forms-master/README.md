# Client-Project

Following informations are clients 
### list of information
- client name,client company,phone,email
- Project id,name,email,company,client 
 
### list  for programming
- Python,django - backend
- Bootstrap4 - Frontend
#### All employees are extracted from three sites.


> #bootsraomodalform is used to add client and project in pop-up form.
> #piechart is used to show status of work. To see information of pie chart hover above it.


```

